<?php
    if(isset($_COOKIE['correctLogin'])){
        header("Location: login.php");
    }
?>